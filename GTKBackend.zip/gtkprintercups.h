/* GtkPrinterCups
 * Copyright (C) 2006 John (J5) Palmieri <johnp@redhat.com>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	 See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library. If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef __GTK_PRINTER_CUPS_H__
#define __GTK_PRINTER_CUPS_H__

#include <glib-object.h>
#include <cups/cups.h>
#include <cups/ppd.h>
#include "gtkcupsutils.h"

#include <gtk/gtkunixprint.h>
#include <gtk/gtkprinter-private.h>

#ifdef HAVE_COLORD
#include <colord.h>
#endif

G_BEGIN_DECLS

#define GTK_TYPE_PRINTER_CUPS                  (gtk_printer_cups_get_type ())
#define GTK_PRINTER_CUPS(obj)                  (G_TYPE_CHECK_INSTANCE_CAST ((obj), GTK_TYPE_PRINTER_CUPS, GtkPrinterCups))
#define GTK_PRINTER_CUPS_CLASS(klass)          (G_TYPE_CHECK_CLASS_CAST ((klass), GTK_TYPE_PRINTER_CUPS, GtkPrinterCupsClass))
#define GTK_IS_PRINTER_CUPS(obj)               (G_TYPE_CHECK_INSTANCE_TYPE ((obj), GTK_TYPE_PRINTER_CUPS))
#define GTK_IS_PRINTER_CUPS_CLASS(klass)       (G_TYPE_CHECK_CLASS_TYPE ((klass), GTK_TYPE_PRINTER_CUPS))
#define GTK_PRINTER_CUPS_GET_CLASS(obj)        (G_TYPE_INSTANCE_GET_CLASS ((obj), GTK_TYPE_PRINTER_CUPS, GtkPrinterCupsClass))

typedef struct _GtkPrinterCups	        GtkPrinterCups;
typedef struct _GtkPrinterCupsClass     GtkPrinterCupsClass;
typedef struct _GtkPrinterCupsPrivate   GtkPrinterCupsPrivate;

struct _GtkPrinterCups
{
  GtkPrinter parent_instance;

  gchar *device_uri;
  gchar *printer_uri;
  gchar *hostname;
  gint port;
  gchar **auth_info_required;

  ipp_pstate_t state;
  gboolean reading_ppd;
  gchar      *ppd_name;
  ppd_file_t *ppd_file;

  gchar    *media_default;
  GList    *media_supported;
  GList    *media_size_supported;
  gint      media_bottom_margin_default;
  gint      media_top_margin_default;
  gint      media_left_margin_default;
  gint      media_right_margin_default;
  gboolean  media_margin_default_set;
  gchar    *sides_default;
  GList    *sides_supported;
  gchar    *output_bin_default;
  GList    *output_bin_supported;

  gchar  *default_cover_before;
  gchar  *default_cover_after;

  gint    default_number_up;

  gboolean remote;
  guint get_remote_ppd_poll;
  gint  get_remote_ppd_attempts;
  
  
  /* Kevin's Code (Start) */
  
  gchar *document_format_default;
  GList *document_format_supported;
  
  gchar *color_supported_default;
  GList *color_supported;
    
  gchar *media_source_default;
  GList *media_source_supported;  
  
  gint print_quality_default;
  GList *print_quality_supported;
  
  gchar *printer_resolution_default;
  GList *printer_resolution_supported;
  
  gchar *copies_default;
  GList *copies_supported;
  
  gchar *media_type_default;
  GList *media_type_supported;
  
  gint *pages_per_side_default;
  GList *pages_per_side_supported;
  
  gchar *page_order_received_default;
  GList *page_order_received_supported;
  
  
  /* Kevin's Code (Marek's patch start) */
  
  gint  finishings_default;  
  GList *finishings_supported;
    
  gchar *presentation_direction_number_up_default;
  GList *presentation_direction_number_up_supported;
  
  gchar *page_delivery_default;
  GList *page_delivery_supported;
    
  gchar *print_color_mode_default;
  GList *print_color_mode_supported;
  
  gchar *print_content_optimize_default;
  GList *print_content_optimize_supported;
    
  gchar *print_scaling_default;
  GList *print_scaling_supported; 
  
  gchar *imposition_template_default;
  GList *imposition_template_supported;
  
  gchar job_account_type_default;
  GList *job_account_type_supported;
  
  gchar *job_delay_output_until_default;
  GList *job_delay_output_until_supported;
    
  gchar *job_error_action_default;
  GList *job_error_action_supported;
  
  gint force_front_side_default;
  GList *force_front_side_suppported;
  
  gchar *print_rendering_intent_default;
  GList *print_rendering_intent_supported;
  
  gchar *x_image_position_default;
  GList *x_image_position_supported;
  
  gchar *y_image_position_default;
  GList *y_image_position_supported;

  /* Kevin's Code (Marek's patch end) */      
  
  /* Kevin's Code (End) */
  
  GtkCupsConnectionTest *remote_cups_connection_test;
#ifdef HAVE_COLORD
  CdClient     *colord_client;
  CdDevice     *colord_device;
  CdProfile    *colord_profile;
  GCancellable *colord_cancellable;
  gchar        *colord_title;
  gchar        *colord_qualifier;
#endif
#ifdef HAVE_CUPS_API_1_6
  gboolean  avahi_browsed;
  gchar    *avahi_name;
  gchar    *avahi_type;
  gchar    *avahi_domain;
#endif
  guchar ipp_version_major;
  guchar ipp_version_minor;
  gboolean supports_copies;
  gboolean supports_collate;
  gboolean supports_number_up;
  char   **covers;
  int      number_of_covers;
};

struct _GtkPrinterCupsClass
{
  GtkPrinterClass parent_class;

};

GType                    gtk_printer_cups_get_type      (void) G_GNUC_CONST;
void                     gtk_printer_cups_register_type (GTypeModule     *module);

GtkPrinterCups          *gtk_printer_cups_new           (const char      *name,
                                                         GtkPrintBackend *backend,
                                                         gpointer         colord_client);
ppd_file_t 		*gtk_printer_cups_get_ppd       (GtkPrinterCups  *printer);
const gchar		*gtk_printer_cups_get_ppd_name  (GtkPrinterCups  *printer);

#ifdef HAVE_COLORD
void                     gtk_printer_cups_update_settings (GtkPrinterCups *printer,
                                                         GtkPrintSettings *settings,
                                                         GtkPrinterOptionSet *set);
#endif

G_END_DECLS

#endif /* __GTK_PRINTER_CUPS_H__ */
